package com.fpsmonitor.app

import android.content.pm.PackageManager
import rikka.shizuku.Shizuku

object Sh {
    private val method by lazy {
        Shizuku::class.java.getDeclaredMethod(
            "newProcess", Array<String>::class.java, Array<String>::class.java, String::class.java
        ).also { it.isAccessible = true }
    }

    fun shizukuReady(): Boolean = try {
        Shizuku.pingBinder() && Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED
    } catch (e: Throwable) { false }

    fun run(cmd: String): String = try {
        val args = arrayOf("sh", "-c", cmd)
        val p = if (shizukuReady()) method.invoke(null, args, null, null) as Process
                else Runtime.getRuntime().exec(args)
        val out = p.inputStream.bufferedReader().readText()
        p.waitFor()
        out
    } catch (e: Throwable) { "" }
}
