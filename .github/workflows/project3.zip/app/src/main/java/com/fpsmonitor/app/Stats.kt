package com.fpsmonitor.app

import android.app.ActivityManager
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.os.BatteryManager

class Snap {
    var cpu: Float? = null; var mhz: Int? = null; var ramMb: Long = 0
    var temp: Float? = null; var pct: Int = 0; var watts: Float? = null
    var fps: Float? = null; var avg: Float? = null; var low: Float? = null; var ms: Float? = null
}

class Stats(private val ctx: Context) {
    private var pTotal = 0L
    private var pIdle = 0L
    private var layer: String? = null
    private var lastResolve = 0L
    private var lastTs = 0L
    private val hist = ArrayList<Float>()

    fun collect(needCpu: Boolean, needFps: Boolean): Snap {
        val s = Snap()
        if (needCpu) cpu(s)
        ram(s)
        battery(s)
        if (needFps) fps(s)
        return s
    }

    private fun cpu(s: Snap) {
        val out = Sh.run("head -n1 /proc/stat; cat /sys/devices/system/cpu/cpu*/cpufreq/scaling_cur_freq 2>/dev/null")
        val lines = out.lines().filter { it.isNotBlank() }
        if (lines.isEmpty()) return
        var idx = 0
        if (lines[0].startsWith("cpu")) {
            val n = lines[0].trim().split(Regex("\\s+")).drop(1).mapNotNull { it.toLongOrNull() }
            if (n.size >= 5) {
                val total = n.take(8).sum()
                val idle = n[3] + n[4]
                if (pTotal > 0 && total > pTotal) {
                    s.cpu = (100f * (1f - (idle - pIdle).toFloat() / (total - pTotal))).coerceIn(0f, 100f)
                }
                pTotal = total; pIdle = idle
            }
            idx = 1
        }
        val f = lines.drop(idx).mapNotNull { it.trim().toLongOrNull() }
        if (f.isNotEmpty()) s.mhz = (f.maxOrNull()!! / 1000).toInt()
    }

    private fun ram(s: Snap) {
        val am = ctx.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
        val mi = ActivityManager.MemoryInfo()
        am.getMemoryInfo(mi)
        s.ramMb = (mi.totalMem - mi.availMem) / 1048576
    }

    private fun battery(s: Snap) {
        val i = ctx.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED)) ?: return
        s.temp = i.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, 0) / 10f
        val sc = i.getIntExtra(BatteryManager.EXTRA_SCALE, 100)
        s.pct = i.getIntExtra(BatteryManager.EXTRA_LEVEL, 0) * 100 / sc
        val v = i.getIntExtra(BatteryManager.EXTRA_VOLTAGE, 0) / 1000f
        val bm = ctx.getSystemService(Context.BATTERY_SERVICE) as BatteryManager
        val cur = Math.abs(bm.getLongProperty(BatteryManager.BATTERY_PROPERTY_CURRENT_NOW)).toFloat()
        if (cur > 0f) s.watts = (if (cur > 20000f) cur / 1_000_000f else cur / 1000f) * v
    }

    private fun resolve() {
        val out = Sh.run(
            "p=\$(dumpsys activity activities | grep -m1 -E 'topResumedActivity|mResumedActivity' | " +
            "sed -E 's/.* ([A-Za-z0-9_.]+)\\/.*/\\1/'); echo PKG:\$p; " +
            "[ -n \"\$p\" ] && dumpsys SurfaceFlinger --list | grep -F \"\$p\""
        )
        val lines = out.lines().map { it.trim() }.filter { it.isNotEmpty() }
        val pkg = lines.firstOrNull { it.startsWith("PKG:") }?.removePrefix("PKG:") ?: ""
        val layers = lines.filter { !it.startsWith("PKG:") }
        val pick = if (pkg.isEmpty()) null else
            layers.firstOrNull { it.startsWith("SurfaceView") && it.contains("BLAST") }
                ?: layers.firstOrNull { it.startsWith("SurfaceView") }
                ?: layers.firstOrNull { it.contains("/") }
                ?: layers.firstOrNull()
        if (pick != layer) { hist.clear(); lastTs = 0L }
        layer = pick
    }

    private fun fps(s: Snap) {
        val now = System.currentTimeMillis()
        if (layer == null || now - lastResolve > 5000) { resolve(); lastResolve = now }
        val l = layer ?: return
        var lines = Sh.run("dumpsys SurfaceFlinger --latency \"$l\"").lines().filter { it.isNotBlank() }
        if (lines.size < 3) {
            val alt = l.replace(Regex("#\\d+$"), "")
            if (alt != l) lines = Sh.run("dumpsys SurfaceFlinger --latency \"$alt\"").lines().filter { it.isNotBlank() }
        }
        val ts = lines.drop(1).mapNotNull {
            val p = it.trim().split(Regex("\\s+"))
            if (p.size >= 3) p[1].toLongOrNull() else null
        }.filter { it > 0 && it < Long.MAX_VALUE / 2 }.sorted()
        if (ts.size < 2) return
        val last = ts.last()
        if (System.nanoTime() - last > 2_000_000_000L) return
        for (i in 1 until ts.size) if (ts[i] > lastTs) hist.add((ts[i] - ts[i - 1]) / 1e6f)
        lastTs = last
        while (hist.size > 1800) hist.removeAt(0)
        val n = ts.count { it > last - 1_000_000_000L }
        s.fps = n.toFloat()
        s.ms = if (n > 0) 1000f / n else null
        if (hist.size > 10) {
            s.avg = 1000f / hist.average().toFloat()
            val worst = hist.sortedDescending().take(maxOf(1, hist.size / 100))
            s.low = 1000f / worst.average().toFloat()
        }
    }
}
