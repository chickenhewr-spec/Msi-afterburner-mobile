package com.fpsmonitor.app

import android.content.Context
import android.content.SharedPreferences

data class Item(val key: String, val label: String, val group: String)

object Prefs {
    val GROUPS = listOf("CPU", "RAM", "BAT", "FPS")
    val ITEMS = listOf(
        Item("cpu_usage", "Usage", "CPU"),
        Item("cpu_clock", "Clock", "CPU"),
        Item("ram", "Used", "RAM"),
        Item("bat_temp", "Temperature", "BAT"),
        Item("bat_pct", "Level", "BAT"),
        Item("bat_w", "Power", "BAT"),
        Item("fps", "FPS", "FPS"),
        Item("fps_avg", "Average", "FPS"),
        Item("fps_low", "1% Low", "FPS"),
        Item("frametime", "Frametime", "FPS")
    )
    fun sp(c: Context): SharedPreferences = c.getSharedPreferences("fpsmon", Context.MODE_PRIVATE)
    fun on(c: Context, key: String) = sp(c).getBoolean(key, true)
    fun int(c: Context, key: String, def: Int) = sp(c).getInt(key, def)
}
