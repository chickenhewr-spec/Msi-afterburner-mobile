package com.fpsmonitor.app

import android.app.*
import android.content.Intent
import android.content.SharedPreferences
import android.graphics.*
import android.graphics.drawable.GradientDrawable
import android.os.*
import android.util.TypedValue
import android.view.*
import android.widget.LinearLayout
import android.widget.TextView
import java.util.Locale

class OverlayService : Service(), SharedPreferences.OnSharedPreferenceChangeListener {
    private lateinit var wm: WindowManager
    private lateinit var lp: WindowManager.LayoutParams
    private lateinit var stats: Stats
    private var root: LinearLayout? = null
    private val views = HashMap<String, TextView>()
    private val ui = Handler(Looper.getMainLooper())
    private var worker: HandlerThread? = null
    private var bg: Handler? = null
    @Volatile private var running = false

    private val labelColors = mapOf(
        "CPU" to 0xFF5B8CFF.toInt(), "RAM" to 0xFF5B8CFF.toInt(),
        "BAT" to 0xFF5B8CFF.toInt(), "FPS" to 0xFFB28CFF.toInt()
    )
    private val valueColor = 0xFFFFA726.toInt()

    companion object { @Volatile var alive = false }

    override fun onBind(i: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        stats = Stats(this)
        val ch = NotificationChannel("fpsmon", "FPS Monitor", NotificationManager.IMPORTANCE_LOW)
        (getSystemService(NOTIFICATION_SERVICE) as NotificationManager).createNotificationChannel(ch)
        startForeground(1, Notification.Builder(this, "fpsmon")
            .setContentTitle("FPS Monitor running")
            .setSmallIcon(android.R.drawable.ic_menu_info_details).build())
        lp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        )
        lp.gravity = Gravity.TOP or Gravity.START
        lp.x = Prefs.int(this, "x", 20)
        lp.y = Prefs.int(this, "y", 150)
        build()
        Prefs.sp(this).registerOnSharedPreferenceChangeListener(this)
        worker = HandlerThread("stats").also { it.start() }
        bg = Handler(worker!!.looper)
        running = true
        alive = true
        bg!!.post(tick)
    }

    override fun onStartCommand(i: Intent?, f: Int, id: Int) = START_STICKY

    override fun onSharedPreferenceChanged(sp: SharedPreferences?, key: String?) {
        if (key == "x" || key == "y") return
        ui.post { build() }
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun tv(text: String, color: Int, size: Float) = TextView(this).apply {
        this.text = text
        setTextColor(color)
        setTextSize(TypedValue.COMPLEX_UNIT_SP, size)
        typeface = Typeface.DEFAULT_BOLD
        setShadowLayer(4f, 0f, 0f, Color.BLACK)
        setPadding(0, 0, dp(10), 0)
    }

    private fun build() {
        try { root?.let { wm.removeView(it) } } catch (e: Throwable) {}
        views.clear()
        val size = Prefs.int(this, "size", 13).toFloat()
        val alpha = Prefs.int(this, "opacity", 55) * 255 / 100
        val r = LinearLayout(this)
        r.orientation = LinearLayout.VERTICAL
        r.setPadding(dp(8), dp(6), dp(8), dp(6))
        r.background = GradientDrawable().apply { setColor(Color.argb(alpha, 0, 0, 0)); cornerRadius = dp(10).toFloat() }
        for (g in Prefs.GROUPS) {
            val items = Prefs.ITEMS.filter { it.group == g && Prefs.on(this, it.key) }
            if (items.isEmpty()) continue
            val row = LinearLayout(this)
            row.orientation = LinearLayout.HORIZONTAL
            row.addView(tv(g, labelColors[g]!!, size).apply { minWidth = dp((size * 3.2f).toInt()) })
            for (it in items) {
                val t = tv("--", valueColor, size)
                views[it.key] = t
                row.addView(t)
            }
            r.addView(row)
        }
        if (views.isEmpty()) r.addView(tv("Nothing enabled", valueColor, size))
        var sx = 0; var sy = 0; var tx = 0f; var ty = 0f
        r.setOnTouchListener { v, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> { sx = lp.x; sy = lp.y; tx = e.rawX; ty = e.rawY }
                MotionEvent.ACTION_MOVE -> {
                    lp.x = sx + (e.rawX - tx).toInt(); lp.y = sy + (e.rawY - ty).toInt()
                    try { wm.updateViewLayout(v, lp) } catch (x: Throwable) {}
                }
                MotionEvent.ACTION_UP -> Prefs.sp(this).edit().putInt("x", lp.x).putInt("y", lp.y).apply()
            }
            true
        }
        root = r
        wm.addView(r, lp)
    }

    private val tick = object : Runnable {
        override fun run() {
            if (!running) return
            val needCpu = Prefs.ITEMS.any { it.group == "CPU" && Prefs.on(this@OverlayService, it.key) }
            val needFps = Prefs.ITEMS.any { it.group == "FPS" && Prefs.on(this@OverlayService, it.key) }
            val s = stats.collect(needCpu, needFps)
            ui.post { render(s) }
            bg?.postDelayed(this, Prefs.int(this@OverlayService, "interval", 1000).toLong())
        }
    }

    private fun f1(v: Float) = String.format(Locale.US, "%.1f", v)

    private fun render(s: Snap) {
        fun set(k: String, t: String) { views[k]?.text = t }
        set("cpu_usage", s.cpu?.let { "${it.toInt()}%" } ?: "--")
        set("cpu_clock", s.mhz?.let { "${it}MHz" } ?: "--")
        set("ram", "${s.ramMb}MB")
        set("bat_temp", s.temp?.let { "${f1(it)}°C" } ?: "--")
        set("bat_pct", "${s.pct}%")
        set("bat_w", s.watts?.let { "${f1(it)}W" } ?: "--")
        set("fps", "FPS " + (s.fps?.toInt()?.toString() ?: "--"))
        set("fps_avg", "AVG " + (s.avg?.toInt()?.toString() ?: "--"))
        set("fps_low", "1%L " + (s.low?.toInt()?.toString() ?: "--"))
        set("frametime", s.ms?.let { "${f1(it)}ms" } ?: "--")
    }

    override fun onDestroy() {
        running = false
        alive = false
        bg?.removeCallbacksAndMessages(null)
        worker?.quit()
        Prefs.sp(this).unregisterOnSharedPreferenceChangeListener(this)
        try { root?.let { wm.removeView(it) } } catch (e: Throwable) {}
        super.onDestroy()
    }
}
