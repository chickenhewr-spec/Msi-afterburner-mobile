package com.fpsmonitor.app

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.View
import android.widget.*
import rikka.shizuku.Shizuku

class MainActivity : Activity() {
    private lateinit var status: TextView
    private var askedOverlay = false
    private var askedShizuku = false
    private var userStopped = false

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun toast(t: String) = Toast.makeText(this, t, Toast.LENGTH_LONG).show()

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        if (Build.VERSION.SDK_INT >= 33) requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        col.setPadding(dp(20), dp(48), dp(20), dp(32))
        val sv = ScrollView(this)
        sv.addView(col)
        setContentView(sv)

        col.addView(TextView(this).apply { text = "FPS Monitor"; textSize = 26f })
        status = TextView(this).apply { setPadding(0, dp(8), 0, dp(8)) }
        col.addView(status)

        fun btn(t: String, a: () -> Unit) = col.addView(Button(this).apply { text = t; setOnClickListener { a() } })
        btn("1. Allow overlay permission") {
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
        }
        btn("2. Allow Shizuku (for CPU and FPS)") {
            try {
                if (Shizuku.pingBinder()) Shizuku.requestPermission(100)
                else toast("Open Shizuku and start it first")
            } catch (e: Throwable) { toast("Open Shizuku and start it first") }
        }
        btn("Start overlay") {
            if (!Settings.canDrawOverlays(this)) toast("Allow overlay permission first")
            else { userStopped = false; startOverlay() }
        }
        btn("Stop overlay") { userStopped = true; stopService(Intent(this, OverlayService::class.java)) }

        val sp = Prefs.sp(this)
        for (g in Prefs.GROUPS) {
            col.addView(TextView(this).apply { text = g; textSize = 18f; setPadding(0, dp(16), 0, 0) })
            for (it in Prefs.ITEMS.filter { x -> x.group == g }) {
                col.addView(Switch(this).apply {
                    text = it.label
                    isChecked = Prefs.on(this@MainActivity, it.key)
                    setOnCheckedChangeListener { _, c -> sp.edit().putBoolean(it.key, c).apply() }
                })
            }
        }

        fun seek(title: String, key: String, min: Int, max: Int, def: Int, unit: String) {
            val label = TextView(this)
            val cur = Prefs.int(this, key, def)
            label.text = "$title: $cur$unit"
            label.setPadding(0, dp(16), 0, 0)
            col.addView(label)
            col.addView(SeekBar(this).apply {
                this.max = max - min
                progress = cur - min
                setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                    override fun onProgressChanged(s: SeekBar?, p: Int, fromUser: Boolean) {
                        label.text = "$title: ${p + min}$unit"
                    }
                    override fun onStartTrackingTouch(s: SeekBar?) {}
                    override fun onStopTrackingTouch(s: SeekBar?) {
                        sp.edit().putInt(key, (s?.progress ?: 0) + min).apply()
                    }
                })
            })
        }
        seek("Text size", "size", 8, 30, 13, "sp")
        seek("Background opacity", "opacity", 0, 100, 55, "%")
        seek("Update interval", "interval", 500, 3000, 1000, "ms")
    }

    private fun startOverlay() {
        val i = Intent(this, OverlayService::class.java)
        if (Build.VERSION.SDK_INT >= 26) startForegroundService(i) else startService(i)
    }

    override fun onResume() {
        super.onResume()
        val sh = try {
            if (!Shizuku.pingBinder()) "not running"
            else if (Sh.shizukuReady()) "ready" else "running, not allowed yet"
        } catch (e: Throwable) { "not running" }
        status.text = "Overlay permission: ${if (Settings.canDrawOverlays(this)) "allowed" else "not allowed"}\nShizuku: $sh"
    
        if (!Settings.canDrawOverlays(this)) {
            if (!askedOverlay) {
                askedOverlay = true
                toast("Turn on 'Display over other apps' for FPS Overlay")
                startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
            }
            return
        }
        try {
            if (Shizuku.pingBinder()) {
                if (!Sh.shizukuReady() && !askedShizuku) { askedShizuku = true; Shizuku.requestPermission(100) }
            } else if (!askedShizuku) {
                askedShizuku = true
                toast("Start Shizuku for CPU and FPS numbers")
            }
        } catch (e: Throwable) {}
        if (!OverlayService.alive && !userStopped) startOverlay()
    }
}
